package com.codegym.customermanagementjpa.repository;

import com.codegym.customermanagementjpa.model.Customer;

public interface ICustomerRepository extends IGenerateRepository<Customer> {
}
