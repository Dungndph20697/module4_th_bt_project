package com.codegym.customermanagementjpa.service;

import com.codegym.customermanagementjpa.model.Customer;

public interface ICustomerService extends IGenerateService<Customer> {
}
